<?php
 

   if ( defined( 'FW' ) ) { 
   // sticky header
   $gloreya_header_nav_sticky = gloreya_option('header_nav_sticky');

	$gloreya_button_settings = gloreya_option('header_table_button_settings');
	//Page settings
	$gloreya_header_btn_show = $gloreya_button_settings['header_btn_show'];
	$gloreya_header_btn_url = $gloreya_button_settings['header_btn_url'];
   $gloreya_header_btn_title = $gloreya_button_settings['header_btn_title'];
   $gloreya_shop_btn_show = gloreya_option('shop_btn_show');
  // of canvas 
  $header_offcanvas_settings = gloreya_option("header_offcanvas_settings");

  $header_offcanvas_show  = $header_offcanvas_settings['header_offcanvas_show'];

   }else{

	$gloreya_header_btn_show = 'no';
   $gloreya_shop_btn_show = 'no';
	$gloreya_header_btn_url = '#';
	$gloreya_header_btn_title = esc_html__('Order Online','gloreya');

   $gloreya_header_nav_sticky = 'no';

   //  off canvas 
   $header_offcanvas_show = 'no';

   }

?>

<!-- header nav start-->
<header id="header" class="header header-transparent <?php echo esc_attr($gloreya_header_nav_sticky=='yes'?'navbar-sticky':''); ?> offcanvas-<?php echo esc_attr($header_offcanvas_show); ?>">
 
        <!-- navbar container start -->
        <div class="navbar-container">
            <div class="container">
               <div class="row">
                  <div class="col-lg-5 align-self-center">
                      <nav class="navbar navbar-expand-lg navbar-light">
                              <a class="navbar-brand d-none" href="<?php echo esc_url( home_url('/')); ?>">
                                 <img src="<?php 
                                    echo esc_url(
                                       gloreya_src(
                                          'general_main_logo',
                                          GLOREYA_IMG . '/logo/logo.png'
                                       )
                                    );
                                 ?>" alt="<?php bloginfo('name'); ?>">
                           </a>
                           <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#primary-nav"
                              aria-controls="primary-nav" aria-expanded="false" aria-label="Toggle navigation">
                              <span class="navbar-toggler-icon"><i class="icon icon-menu"></i></span>
                           </button>
                           <?php get_template_part( 'template-parts/navigations/nav', 'primary' ); ?>
                           <!-- collapse end -->
                     </nav>
                     <!-- nav end -->
                  </div>
                  <div class="col-lg-2">
                     <div class="nav-logo text-center">
                        <a class="logo" href="<?php echo esc_url( home_url('/') ); ?>">
                              <img src="<?php 
                                 echo esc_url(
                                    gloreya_src(
                                       'general_main_logo',
                                       GLOREYA_IMG . '/logo/logo.png'
                                    )
                                 );
                              ?>" alt="<?php bloginfo('name'); ?>">
                           </a>
                     </div>
                  </div>
                  <div class="col-lg-5 align-self-center">
                     
                        <?php if(defined('FW')): ?>
                        <ul class="header-nav-right-info float-right">
                         <?php if($gloreya_header_btn_show=='yes'): ?>
                              <li class="header-book-btn">
                                    <a href="<?php echo esc_url($gloreya_header_btn_url); ?>" class="btn btn-primary"><?php echo esc_html($gloreya_header_btn_title); ?></a>
                              </li>
                           <?php endif; ?>
                           <?php if($gloreya_shop_btn_show == "yes" && class_exists( 'WooCommerce' )): ?>
                              <li>
                                 <div class="header-cart">
                                    <div class="cart-link">
                                       <a class="cart-contents" href="<?php echo wc_get_cart_url(); ?>" title="<?php _e('View your shopping cart', 'gloreya'); ?>">
                                       <span class="icon icon-tscart"></span>
                                       <sup><?php echo sprintf(_n('%d item', '%d', WC()->cart->cart_contents_count, 'gloreya'), WC()->cart->cart_contents_count);?></sup>
                                       
                                       </a>
                                    </div>
                                 </div>
                              </li>
                           <?php endif; ?> 
                           
                           <!-- off canvas -->
                           <?php if($header_offcanvas_show == 'yes'): ?>
                           <li>
                              <a href="#" class="navSidebar-button">
                                 <i class="icon icon-humburger"></i>
                              </a>
                           </li>
                           <?php endif; ?>
                      
                        </ul>
                     <?php endif; ?>
                  </div>
               </div>
              
            </div>
            <!-- container end -->
        </div>
        <!-- navbar contianer end -->
</header>

<?php get_template_part( 'template-parts/navigations/offcanvas', 'menu' ); ?>

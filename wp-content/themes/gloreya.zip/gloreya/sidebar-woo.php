
<aside id="sidebar" class="sidebar sidebar-right sidebar-woo col-md-3">
	<?php dynamic_sidebar( 'sidebar-woo' ); ?>
</aside> <!-- end sidebar -->


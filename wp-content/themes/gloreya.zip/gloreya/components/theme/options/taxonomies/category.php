<?php if (!defined('ABSPATH')) die('Direct access forbidden.');

$options = array(
    'gloreya_product_cat'=>array(
        'type'  => 'new-icon',
        'label' =>esc_html__('Category icon', 'gloreya'),
        'desc'  =>esc_html__('Category icon', 'gloreya'),
    ),
);